Brana Browser (Android)
1. Buka folder ini di Android Studio (Koala atau lebih baru), tunggu Gradle sync.
2. Build > Build Bundle(s)/APK(s) > Build APK(s).
3. APK ada di app/build/outputs/apk/debug/app-debug.apk
