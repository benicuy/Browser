package com.brana.browser

import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.inputmethod.EditorInfo
import android.webkit.*
import android.widget.*

class MainActivity : Activity() {
    class Tab(val web: WebView, var title: String = "Tab baru")

    private val tabs = mutableListOf<Tab>()
    private var cur = 0
    private var desktop = false
    private lateinit var omni: EditText
    private lateinit var bar: ProgressBar
    private lateinit var strip: LinearLayout
    private lateinit var holder: FrameLayout
    private lateinit var prefs: SharedPreferences
    private val BG = Color.parseColor("#0E1116")
    private val SURF = Color.parseColor("#1A1F2B")
    private val ACC = Color.parseColor("#7C5CFF")
    private val SEP = "\u0001"
    private val DESKTOP_UA = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36"

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun pill(c: Int, r: Int = 22) = GradientDrawable().apply { setColor(c); cornerRadius = dp(r).toFloat() }
    private fun cleanUrl(u: String?) = if (u == null || u.contains("brana.home") || u == "about:blank") "" else u

    private val HOME = """<html><head><meta name=viewport content='width=device-width,initial-scale=1'><style>
body{margin:0;background:#0E1116;color:#fff;font-family:sans-serif;text-align:center;padding-top:22vh}
h1{font-size:40px;font-weight:600;letter-spacing:-1px;margin:0 0 6px;background:linear-gradient(90deg,#B9A8FF,#7C5CFF);-webkit-background-clip:text;color:transparent}
p{color:#8A93A6;margin:0 0 28px}input{width:82%;max-width:480px;height:50px;border-radius:25px;border:1px solid #2A3142;background:#1A1F2B;color:#fff;padding:0 22px;font-size:16px;outline:0}
input:focus{border-color:#7C5CFF}</style></head><body><h1>Brana</h1><p>Jelajahi tanpa batas</p>
<form action='https://duckduckgo.com/'><input name=q placeholder='Telusuri atau ketik URL'></form></body></html>"""

    @SuppressLint("SetTextI18n")
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        prefs = getSharedPreferences("brana", Context.MODE_PRIVATE)
        window.statusBarColor = BG
        window.navigationBarColor = BG

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(BG) }
        strip = LinearLayout(this).apply { setPadding(dp(8), dp(6), dp(8), dp(2)) }
        root.addView(HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(strip) })

        val tool = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(6), dp(4), dp(6), dp(6)) }
        fun btn(t: String, a: () -> Unit) = TextView(this).apply {
            text = t; textSize = 19f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(dp(40), dp(40)); setOnClickListener { a() }
        }
        omni = EditText(this).apply {
            setSingleLine(); hint = "Telusuri atau ketik URL"; setHintTextColor(Color.parseColor("#6B7385"))
            setTextColor(Color.WHITE); textSize = 15f; background = pill(SURF); setPadding(dp(18), 0, dp(18), 0)
            imeOptions = EditorInfo.IME_ACTION_GO; inputType = android.text.InputType.TYPE_TEXT_VARIATION_URI
            layoutParams = LinearLayout.LayoutParams(0, dp(44), 1f).apply { marginStart = dp(2); marginEnd = dp(2) }
            setOnEditorActionListener { _, _, _ -> load(omni.text.toString()); clearFocus(); true }
            setOnFocusChangeListener { _, f -> if (f) selectAll() }
        }
        tool.addView(btn("‹") { web().let { if (it.canGoBack()) it.goBack() } })
        tool.addView(btn("›") { web().let { if (it.canGoForward()) it.goForward() } })
        tool.addView(omni)
        tool.addView(btn("⟳") { web().reload() })
        tool.addView(btn("⋮") { showMenu(it) })
        root.addView(tool)

        bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100; progressTintList = android.content.res.ColorStateList.valueOf(ACC)
            layoutParams = LinearLayout.LayoutParams(-1, dp(3)); visibility = View.INVISIBLE
        }
        root.addView(bar)
        holder = FrameLayout(this)
        root.addView(holder, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)

        val start = intent?.data?.toString()
        newTab(start)
    }

    private fun web() = tabs[cur].web

    private fun norm(s: String): String {
        val t = s.trim()
        if (t.isEmpty()) return ""
        if (Regex("^https?://.*", RegexOption.IGNORE_CASE).matches(t)) return t
        if (!t.contains(" ") && Regex("^[\\w-]+(\\.[\\w-]+)+(/.*)?$").matches(t)) return "https://$t"
        return "https://duckduckgo.com/?q=" + Uri.encode(t)
    }

    private fun load(s: String) { val u = norm(s); if (u.isNotEmpty()) web().loadUrl(u) }

    @SuppressLint("SetJavaScriptEnabled")
    private fun newTab(u: String?) {
        val w = WebView(this)
        val tab = Tab(w)
        w.settings.apply {
            javaScriptEnabled = true; domStorageEnabled = true; builtInZoomControls = true
            displayZoomControls = false; mediaPlaybackRequiresUserGesture = false
            setSupportMultipleWindows(false); loadWithOverviewMode = desktop; useWideViewPort = desktop
            userAgentString = if (desktop) DESKTOP_UA else null
        }
        w.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean {
                val sc = r.url.scheme ?: return false
                if (sc == "http" || sc == "https" || sc == "about" || sc == "data") return false
                try { startActivity(Intent(Intent.ACTION_VIEW, r.url)) } catch (_: Exception) {}
                return true
            }
            override fun onPageStarted(v: WebView, url: String?, f: android.graphics.Bitmap?) {
                bar.visibility = View.VISIBLE
                if (tabs.getOrNull(cur)?.web === v) omni.setText(cleanUrl(url))
            }
            override fun onPageFinished(v: WebView, url: String?) {
                bar.visibility = View.INVISIBLE
                if (cleanUrl(url).isNotEmpty()) addTo("hist", v.title ?: url!!, url!!, 100)
            }
        }
        w.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(v: WebView, p: Int) { bar.progress = p }
            override fun onReceivedTitle(v: WebView, t: String?) { tab.title = t ?: "Tab baru"; refreshStrip() }
        }
        w.setDownloadListener { url, ua, cd, mime, _ ->
            val rq = DownloadManager.Request(Uri.parse(url)).apply {
                setMimeType(mime); addRequestHeader("User-Agent", ua)
                setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                setDestinationInExternalPublicDir(android.os.Environment.DIRECTORY_DOWNLOADS, URLUtil.guessFileName(url, cd, mime))
            }
            (getSystemService(DOWNLOAD_SERVICE) as DownloadManager).enqueue(rq)
            Toast.makeText(this, "Mengunduh…", Toast.LENGTH_SHORT).show()
        }
        tabs.add(tab); cur = tabs.size - 1
        show()
        if (u.isNullOrEmpty()) w.loadDataWithBaseURL("https://brana.home", HOME, "text/html", "utf-8", null) else w.loadUrl(norm(u))
    }

    private fun show() {
        holder.removeAllViews(); holder.addView(web())
        omni.setText(cleanUrl(web().url)); refreshStrip()
    }

    private fun closeTab(i: Int) {
        tabs[i].web.destroy(); tabs.removeAt(i)
        if (tabs.isEmpty()) { newTab(null); return }
        if (cur >= tabs.size) cur = tabs.size - 1
        show()
    }

    private fun refreshStrip() {
        strip.removeAllViews()
        tabs.forEachIndexed { i, t ->
            val chip = LinearLayout(this).apply {
                gravity = Gravity.CENTER_VERTICAL; setPadding(dp(14), 0, dp(6), 0)
                background = pill(if (i == cur) ACC else SURF, 18)
                layoutParams = LinearLayout.LayoutParams(dp(150), dp(36)).apply { marginEnd = dp(6) }
                setOnClickListener { cur = i; show() }
            }
            chip.addView(TextView(this).apply {
                text = t.title; setTextColor(Color.WHITE); textSize = 13f; setSingleLine()
                ellipsize = android.text.TextUtils.TruncateAt.END; layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
            })
            chip.addView(TextView(this).apply {
                text = "✕"; setTextColor(Color.WHITE); gravity = Gravity.CENTER
                layoutParams = LinearLayout.LayoutParams(dp(28), dp(28)); setOnClickListener { closeTab(i) }
            })
            strip.addView(chip)
        }
        strip.addView(TextView(this).apply {
            text = "+"; textSize = 20f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(dp(36), dp(36)); setOnClickListener { newTab(null) }
        })
    }

    private fun getList(k: String): List<Pair<String, String>> =
        (prefs.getString(k, "") ?: "").split("\n").filter { it.contains(SEP) }
            .map { val p = it.split(SEP); p[0] to p[1] }

    private fun addTo(k: String, t: String, u: String, max: Int) {
        val l = getList(k).filter { it.second != u }.toMutableList()
        l.add(0, t.replace("\n", " ") to u)
        prefs.edit().putString(k, l.take(max).joinToString("\n") { it.first + SEP + it.second }).apply()
    }

    private fun listDialog(title: String, k: String, store: Boolean) {
        val l = getList(k)
        if (l.isEmpty()) { Toast.makeText(this, "Masih kosong", Toast.LENGTH_SHORT).show(); return }
        AlertDialog.Builder(this).setTitle(title)
            .setItems(l.map { it.first }.toTypedArray()) { _, i -> web().loadUrl(l[i].second) }
            .setNegativeButton("Tutup", null)
            .also { if (store) it.setNeutralButton("Hapus semua") { _, _ -> prefs.edit().remove(k).apply() } }
            .show()
    }

    private fun showMenu(anchor: View) {
        val m = PopupMenu(this, anchor)
        listOf("Tab baru", "Tambah bookmark", "Bookmark", "Riwayat", "Cari di halaman",
            if (desktop) "Mode seluler" else "Mode desktop", "Bagikan", "Hapus data penjelajahan")
            .forEachIndexed { i, s -> m.menu.add(0, i, i, s) }
        m.setOnMenuItemClickListener {
            when (it.itemId) {
                0 -> newTab(null)
                1 -> { val u = cleanUrl(web().url); if (u.isNotEmpty()) { addTo("bm", web().title ?: u, u, 200); Toast.makeText(this, "Bookmark disimpan", Toast.LENGTH_SHORT).show() } }
                2 -> listDialog("Bookmark", "bm", false)
                3 -> listDialog("Riwayat", "hist", true)
                4 -> findDialog()
                5 -> {
                    desktop = !desktop
                    web().settings.apply { userAgentString = if (desktop) DESKTOP_UA else null; useWideViewPort = desktop; loadWithOverviewMode = desktop }
                    web().reload()
                }
                6 -> startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, web().url), "Bagikan"))
                7 -> {
                    CookieManager.getInstance().removeAllCookies(null); WebStorage.getInstance().deleteAllData()
                    tabs.forEach { t -> t.web.clearCache(true); t.web.clearHistory() }
                    prefs.edit().remove("hist").apply(); Toast.makeText(this, "Data dihapus", Toast.LENGTH_SHORT).show()
                }
            }
            true
        }
        m.show()
    }

    private fun findDialog() {
        val e = EditText(this).apply { hint = "Cari kata" }
        AlertDialog.Builder(this).setTitle("Cari di halaman").setView(e)
            .setPositiveButton("Cari") { _, _ -> web().findAllAsync(e.text.toString()) }
            .setNegativeButton("Bersihkan") { _, _ -> web().clearMatches() }.show()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        when {
            web().canGoBack() -> web().goBack()
            tabs.size > 1 -> closeTab(cur)
            else -> super.onBackPressed()
        }
    }
}
